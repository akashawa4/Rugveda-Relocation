import React, { useState } from 'react';
import { Star, ArrowRight, Phone, Filter, Search } from 'lucide-react';

interface Review {
  name: string;
  location: string;
  rating: number;
  date: string;
  review: string;
  service: string;
  image?: string;
}

const Reviews = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const reviews: Review[] = [
    {
      name: "Jennifer Smith",
      location: "Miami, FL",
      rating: 5,
      date: "March 15, 2024",
      review: "Exceptional service from start to finish! The team was professional, efficient, and handled our belongings with utmost care. They made our cross-country move stress-free.",
      service: "Long Distance Moving",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Michael Johnson",
      location: "Orlando, FL",
      rating: 5,
      date: "March 10, 2024",
      review: "Best moving experience ever! The packing service was incredible, and they were so careful with our antique furniture. Highly recommend!",
      service: "Packing Services",
      image: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Sarah Williams",
      location: "Tampa, FL",
      rating: 5,
      date: "March 5, 2024",
      review: "Very impressed with their professionalism and efficiency. They made our office relocation seamless with minimal disruption to our business.",
      service: "Commercial Moving",
      image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "David Chen",
      location: "Jacksonville, FL",
      rating: 5,
      date: "March 1, 2024",
      review: "The storage solution they provided was perfect for our needs. Clean, secure facility and great customer service throughout.",
      service: "Storage Services",
      image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Emily Rodriguez",
      location: "Miami Beach, FL",
      rating: 5,
      date: "February 28, 2024",
      review: "Outstanding local moving service! The team was punctual, professional, and went above and beyond to ensure everything was perfect.",
      service: "Local Moving",
      image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Robert Wilson",
      location: "Fort Lauderdale, FL",
      rating: 5,
      date: "February 25, 2024",
      review: "Their packing service was a lifesaver! Everything arrived intact, and they even helped unpack at our new home. Worth every penny!",
      service: "Packing Services",
      image: "https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    }
  ];

  const filters = [
    'all',
    'Local Moving',
    'Long Distance Moving',
    'Commercial Moving',
    'Packing Services',
    'Storage Services'
  ];

  const filteredReviews = reviews.filter(review => {
    const matchesFilter = activeFilter === 'all' || review.service === activeFilter;
    const matchesSearch = review.review.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <>
      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-800">
          <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/4246120/pexels-photo-4246120.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] opacity-10 bg-cover bg-center"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-blue-900/50 to-blue-900/90"></div>
        </div>
        
        <div className="container relative mx-auto px-4 md:px-6 text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Customer Testimonials</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto mb-8">
            See what our satisfied customers have to say about their moving experience with us.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              <span className="text-yellow-400">★★★★★</span> 4.9/5 (500+ Reviews)
            </div>
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              Verified Reviews
            </div>
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              10,000+ Happy Customers
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6">
          {/* Search and Filter */}
          <div className="mb-12">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="w-full md:w-96 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search reviews..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div className="flex items-center gap-2 overflow-x-auto pb-2 w-full md:w-auto">
                <Filter className="h-5 w-5 text-gray-500" />
                {filters.map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setActiveFilter(filter)}
                    className={`px-4 py-2 rounded-full whitespace-nowrap ${
                      activeFilter === filter
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {filter === 'all' ? 'All Reviews' : filter}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Reviews Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredReviews.map((review, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <img 
                    src={review.image} 
                    alt={review.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-bold text-gray-900">{review.name}</h3>
                    <p className="text-sm text-gray-600">{review.location}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex text-yellow-400">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">{review.date}</span>
                </div>
                <p className="text-gray-600 mb-4">{review.review}</p>
                <div className="text-sm text-blue-600 font-medium">{review.service}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Experience Our Service?</h2>
            <p className="text-xl text-blue-100 mb-8">
              Join our thousands of satisfied customers. Get your free moving quote today.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a 
                href="/quote" 
                className="inline-flex items-center justify-center bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
              >
                Get Your Free Quote
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
              <a 
                href="tel:+18001234567" 
                className="inline-flex items-center justify-center bg-white/10 hover:bg-white/20 text-white px-8 py-4 rounded-lg font-medium transition-colors"
              >
                <Phone className="h-5 w-5 mr-2" />
                Call Us Now
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Reviews;