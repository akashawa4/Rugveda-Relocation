import React, { useState, useCallback, memo } from 'react';
import { 
  Truck, Home, Building2, PackageCheck, WarehouseIcon, Box,
  ShieldCheck, Users, DollarSign, Clock, Headphones,
  ChevronDown, ChevronUp, ArrowRight, Car, Package
} from 'lucide-react';
import { useInView } from 'react-intersection-observer';

const LazyImage = memo(({ src, alt }: { src: string; alt: string }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
    rootMargin: '50px',
  });

  return (
    <div 
      ref={ref}
      className="aspect-w-16 aspect-h-9 overflow-hidden bg-gray-100"
    >
      {inView && (
        <picture>
          <source
            type="image/webp"
            srcSet={`${src}?format=webp&w=400 400w, ${src}?format=webp&w=800 800w`}
            sizes="(max-width: 768px) 100vw, 33vw"
          />
          <img
            src={`${src}?w=800`}
            srcSet={`${src}?w=400 400w, ${src}?w=800 800w`}
            sizes="(max-width: 768px) 100vw, 33vw"
            alt={alt}
            loading="lazy"
            decoding="async"
            className={`w-full h-64 object-cover transform transition-all duration-300 ${
              isLoaded ? 'scale-100 opacity-100' : 'scale-105 opacity-0'
            } group-hover:scale-105`}
            onLoad={() => setIsLoaded(true)}
          />
        </picture>
      )}
      {!isLoaded && inView && (
        <div className="absolute inset-0 bg-gray-200 animate-pulse" />
      )}
    </div>
  );
});

LazyImage.displayName = 'LazyImage';

const ServiceCard = memo(({ icon, title, description, features, image }: {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
  image: string;
}) => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <div 
      ref={ref}
      className={`bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl group ${
        inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      }`}
      style={{ contentVisibility: 'auto' }}
    >
      <LazyImage src={image} alt={title} />
      <div className="p-8">
        <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300 transform group-hover:scale-110 group-hover:rotate-6">
          {icon}
        </div>
        <h3 className="text-2xl font-bold text-gray-800 mb-4">{title}</h3>
        <p className="text-gray-600 mb-6 leading-relaxed">{description}</p>
        <ul className="space-y-3 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-gray-600">
              <ShieldCheck className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
              {feature}
            </li>
          ))}
        </ul>
        <a 
          href="/quote" 
          className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800 transition-colors group-hover:translate-x-2 transform transition-transform"
        >
          Get a Quote
          <ArrowRight className="ml-2 h-5 w-5" />
        </a>
      </div>
    </div>
  );
});

ServiceCard.displayName = 'ServiceCard';

const FAQItem = memo(({ question, answer }: { question: string; answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-gray-200 last:border-0">
      <button
        className="w-full py-6 text-left flex justify-between items-center focus:outline-none"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-lg font-semibold text-gray-800">{question}</span>
        {isOpen ? (
          <ChevronUp className="h-5 w-5 text-blue-600" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-400" />
        )}
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-96 pb-6' : 'max-h-0'
        }`}
      >
        <p className="text-gray-600 leading-relaxed">{answer}</p>
      </div>
    </div>
  );
});

FAQItem.displayName = 'FAQItem';

const Services = () => {
  const services = [
    {
      icon: <Home className="h-8 w-8" />,
      title: "Household Shifting",
      description: "We offer top-notch Packers and Movers services for hassle-free home shifting. With skilled professionals, we ensure safe handling and transportation of belongings.",
      image: "https://images.pexels.com/photos/4246120/pexels-photo-4246120.jpeg",
      features: [
        "Professional packing materials",
        "Safe handling of belongings",
        "Comprehensive moving solutions",
        "Door-to-door service"
      ]
    },
    {
      icon: <Car className="h-8 w-8" />,
      title: "Vehicle Transport",
      description: "Efficient bike and car transportation services, ensuring the safe delivery of your vehicles to your desired destination. With specialized equipment and experienced professionals.",
      image: "https://images.pexels.com/photos/2199293/pexels-photo-2199293.jpeg",
      features: [
        "Specialized transport equipment",
        "Secure vehicle handling",
        "Door-to-door delivery",
        "Insurance coverage"
      ]
    },
    {
      icon: <Building2 className="h-8 w-8" />,
      title: "Office & Corporate Relocation",
      description: "Top-notch office and corporate relocation services, tailored to meet the dynamic needs of businesses. Our experienced team handles every aspect, from packing to setup.",
      image: "https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg",
      features: [
        "Minimal business disruption",
        "IT equipment handling",
        "Systematic approach",
        "Weekend moving options"
      ]
    },
    {
      icon: <Package className="h-8 w-8" />,
      title: "Loading & Unloading",
      description: "Proficient loading and unloading services for your belongings, ensuring safe handling throughout the relocation process. Our experienced team employs efficient techniques.",
      image: "https://images.pexels.com/photos/1267338/pexels-photo-1267338.jpeg",
      features: [
        "Professional handling",
        "Modern equipment usage",
        "Careful item placement",
        "Efficient process"
      ]
    },
    {
      icon: <WarehouseIcon className="h-8 w-8" />,
      title: "Warehousing & Storage",
      description: "Comprehensive warehousing and storage services, providing secure facilities for your belongings during transitions or long-term storage needs. Modern security systems included.",
      image: "https://images.pexels.com/photos/236705/pexels-photo-236705.jpeg",
      features: [
        "Climate-controlled facilities",
        "24/7 security monitoring",
        "Flexible storage terms",
        "Easy access options"
      ]
    },
    {
      icon: <Box className="h-8 w-8" />,
      title: "Packing & Unpacking",
      description: "Professional packing and unpacking services in Kolhapur. With skilled professionals and modern equipment, we ensure safe handling of your belongings throughout the process.",
      image: "https://images.pexels.com/photos/4246266/pexels-photo-4246266.jpeg",
      features: [
        "Quality packing materials",
        "Systematic organization",
        "Fragile item handling",
        "Unpacking assistance"
      ]
    }
  ];

  const faqs = [
    {
      question: "What should I do to prepare for my move?",
      answer: "Start by decluttering and organizing your belongings. Create an inventory of items, notify important parties of your address change, and pack a box of essentials you'll need immediately in your new home. Our team will provide a detailed moving checklist upon booking."
    },
    {
      question: "How do you protect fragile items?",
      answer: "We use professional-grade packing materials and techniques specific to each item type. Fragile items are wrapped individually, cushioned with appropriate materials, and packed in reinforced boxes. We also offer custom crating for extremely delicate or valuable items."
    },
    {
      question: "Do you offer storage solutions?",
      answer: "Yes, we provide secure, climate-controlled storage facilities for both short-term and long-term needs. Our warehouses are equipped with modern security systems and are regularly monitored to ensure the safety of your belongings."
    },
    {
      question: "What is your pricing structure?",
      answer: "Our pricing is transparent and based on factors such as distance, volume of items, special handling requirements, and additional services needed. We provide detailed written estimates after an in-home assessment or virtual survey."
    }
  ];

  return (
    <>
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-blue-800">
          <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/4246120/pexels-photo-4246120.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] opacity-10 bg-cover bg-center"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-blue-900/50 to-blue-900/90"></div>
        </div>
        
        <div className="container relative mx-auto px-4 md:px-6 text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Moving Services</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto mb-8">
            Comprehensive moving solutions tailored to your specific needs. 
            From local moves to long-distance relocations, we handle everything with care and professionalism.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              <span className="text-yellow-400">★★★★★</span> 4.9/5 (500+ Reviews)
            </div>
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              Licensed & Insured
            </div>
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              Professional Service
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Services We Provide
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience comprehensive moving solutions tailored to meet your specific needs
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Our Moving Services?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience the difference with our professional moving services
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <ShieldCheck className="h-8 w-8" />,
                title: "Licensed & Insured",
                description: "Full coverage for your peace of mind"
              },
              {
                icon: <Users className="h-8 w-8" />,
                title: "Expert Team",
                description: "Trained and experienced movers"
              },
              {
                icon: <DollarSign className="h-8 w-8" />,
                title: "Clear Pricing",
                description: "No hidden fees or surprises"
              },
              {
                icon: <Clock className="h-8 w-8" />,
                title: "On-Time Service",
                description: "We value your schedule"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg group hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-gray-600">
              Get answers to common questions about our moving services
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            {faqs.map((faq, index) => (
              <FAQItem key={index} {...faq} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Move?</h2>
            <p className="text-xl text-blue-100 mb-8">
              Get in touch with us today for a free, no-obligation quote for your move.
            </p>
            <a 
              href="/quote" 
              className="inline-block bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
            >
              Get Your Free Quote
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;