import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface TestimonialProps {
  name: string;
  location: string;
  rating: number;
  testimonial: string;
  image?: string;
}

const TestimonialCard = ({ name, location, rating, testimonial, image }: TestimonialProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full flex flex-col">
      <div className="flex items-center mb-4">
        <div className="w-12 h-12 rounded-full overflow-hidden mr-4 flex-shrink-0">
          {image ? (
            <img src={image} alt={name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-lg">
              {name.charAt(0)}
            </div>
          )}
        </div>
        <div>
          <h3 className="font-bold text-gray-800">{name}</h3>
          <p className="text-sm text-gray-600">{location}</p>
        </div>
      </div>
      
      <div className="flex text-yellow-400 mb-3">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className="h-4 w-4"
            fill={i < rating ? "currentColor" : "none"}
            stroke={i < rating ? "currentColor" : "currentColor"}
          />
        ))}
      </div>
      
      <p className="text-gray-700 flex-grow">"{testimonial}"</p>
    </div>
  );
};

const Testimonials = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const testimonials = [
    {
      name: "Jennifer L.",
      location: "Miami, FL",
      rating: 5,
      testimonial: "The team was incredibly professional and efficient. They handled our belongings with care and made our cross-country move stress-free. I highly recommend their services to anyone planning a move.",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Michael R.",
      location: "Boston, MA",
      rating: 5,
      testimonial: "From start to finish, the moving process was smooth and well-coordinated. The team arrived on time, worked quickly, and ensured everything was placed exactly where we wanted in our new home.",
      image: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Sarah K.",
      location: "Chicago, IL",
      rating: 4,
      testimonial: "This was my first time using professional movers, and I'm so glad I chose this company. They were transparent about pricing and handled a few fragile antiques with exceptional care.",
      image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "David T.",
      location: "Austin, TX",
      rating: 5,
      testimonial: "Moving our office was a daunting task, but the team made it seamless. They worked after hours to minimize business disruption and had us up and running in our new location quickly.",
      image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Emily J.",
      location: "Seattle, WA",
      rating: 5,
      testimonial: "The packing service was a lifesaver! Everything arrived intact, and they even helped unpack the essentials so we could settle in right away. Worth every penny.",
      image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Robert M.",
      location: "Denver, CO",
      rating: 4,
      testimonial: "Friendly, efficient, and careful with our belongings. The only reason for 4 stars instead of 5 is a slight delay in arrival, but they more than made up for it with their service.",
      image: "https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    }
  ];
  
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === Math.ceil(testimonials.length / 3) - 1 ? 0 : prev + 1));
  };
  
  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? Math.ceil(testimonials.length / 3) - 1 : prev - 1));
  };

  return (
    <section className="py-20 bg-white" id="testimonials">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
          <p className="max-w-2xl mx-auto text-gray-600 text-lg">
            We're proud to have helped thousands of families and businesses with their moving needs. Here's what some of them have to say:
          </p>
          <div className="mt-4 flex items-center justify-center space-x-2">
            <div className="flex text-yellow-400">
              <Star className="h-5 w-5" fill="currentColor" />
              <Star className="h-5 w-5" fill="currentColor" />
              <Star className="h-5 w-5" fill="currentColor" />
              <Star className="h-5 w-5" fill="currentColor" />
              <Star className="h-5 w-5" fill="currentColor" />
            </div>
            <span className="font-bold text-gray-800">4.9 out of 5</span>
            <span className="text-gray-600">based on 500+ reviews</span>
          </div>
        </div>
        
        {/* Desktop Testimonials (3 columns) */}
        <div className="hidden lg:block relative">
          <div className="grid grid-cols-3 gap-8">
            {testimonials.slice(currentSlide * 3, currentSlide * 3 + 3).map((testimonial, index) => (
              <TestimonialCard 
                key={index}
                name={testimonial.name}
                location={testimonial.location}
                rating={testimonial.rating}
                testimonial={testimonial.testimonial}
                image={testimonial.image}
              />
            ))}
          </div>
          
          {/* Navigation Controls */}
          <button 
            onClick={prevSlide}
            className="absolute top-1/2 -left-6 transform -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center text-gray-800 hover:bg-gray-100 transition-colors focus:outline-none"
            aria-label="Previous testimonials"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute top-1/2 -right-6 transform -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center text-gray-800 hover:bg-gray-100 transition-colors focus:outline-none"
            aria-label="Next testimonials"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
        
        {/* Tablet Testimonials (2 columns) */}
        <div className="hidden md:block lg:hidden">
          <div className="grid grid-cols-2 gap-6">
            {testimonials.slice(0, 4).map((testimonial, index) => (
              <TestimonialCard 
                key={index}
                name={testimonial.name}
                location={testimonial.location}
                rating={testimonial.rating}
                testimonial={testimonial.testimonial}
                image={testimonial.image}
              />
            ))}
          </div>
        </div>
        
        {/* Mobile Testimonials (1 column) */}
        <div className="md:hidden">
          <div className="space-y-6">
            {testimonials.slice(0, 3).map((testimonial, index) => (
              <TestimonialCard 
                key={index}
                name={testimonial.name}
                location={testimonial.location}
                rating={testimonial.rating}
                testimonial={testimonial.testimonial}
                image={testimonial.image}
              />
            ))}
          </div>
        </div>
        
        <div className="text-center mt-10">
          <a 
            href="/testimonials"
            className="inline-block font-medium text-blue-600 hover:text-blue-800 transition-colors"
          >
            Read More Customer Reviews →
          </a>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;